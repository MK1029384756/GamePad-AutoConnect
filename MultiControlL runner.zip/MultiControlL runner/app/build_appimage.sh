#!/bin/bash
set -e
APP_NAME="Xbox360_Controller_Manager"
VERSION="1.0.0"
ARCH="x86_64"

echo "=== Building Self-Contained AppImage for ${APP_NAME} ==="

WORKDIR="$(dirname "$(readlink -f "${BASH_SOURCE[0]}")")"
cd "$WORKDIR"

# Create AppDir structure
APPDIR="AppDir"
rm -rf "$APPDIR"
mkdir -p "$APPDIR/usr/bin"
mkdir -p "$APPDIR/usr/lib/python3/site-packages"
mkdir -p "$APPDIR/usr/share/applications"
mkdir -p "$APPDIR/usr/share/icons/hicolor/256x256/apps"

# Copy application files
cp main.py "$APPDIR/usr/bin/xbox_manager.py"
chmod +x "$APPDIR/usr/bin/xbox_manager.py"

cp xbox_manager.desktop "$APPDIR/usr/share/applications/"
cp xbox_manager.desktop "$APPDIR/"
cp xbox_manager.png "$APPDIR/usr/share/icons/hicolor/256x256/apps/"
cp xbox_manager.png "$APPDIR/"

# Create robust AppRun entrypoint
cat << 'EOF' > "$APPDIR/AppRun"
#!/bin/bash
HERE="$(dirname "$(readlink -f "${BASH_SOURCE[0]}")")"
export PATH="$HERE/usr/bin:$PATH"
export PYTHONPATH="$HERE/usr/lib/python3/site-packages:$PYTHONPATH"
export PYTHONUNBUFFERED=1

cd "$HERE"

# Ensure execution context and permissions
if [[ -n "$APPIMAGE" ]] && [[ -f "$APPIMAGE" ]]; then
    chmod +x "$APPIMAGE" 2>/dev/null || true
fi

exec python3 "$HERE/usr/bin/xbox_manager.py" "$@"
EOF
chmod +x "$APPDIR/AppRun"

echo "AppDir assembled successfully."

# Build AppImage with ARCH specified
if command -v appimagetool &> /dev/null; then
    echo "Generating standalone .AppImage..."
    ARCH=x86_64 appimagetool "$APPDIR" "${APP_NAME}-${VERSION}-${ARCH}.AppImage"
    chmod +x "${APP_NAME}-${VERSION}-${ARCH}.AppImage"
    echo "Successfully generated: ${APP_NAME}-${VERSION}-${ARCH}.AppImage"
else
    echo "appimagetool not found in PATH."
fi

echo "=== Build completed successfully ==="

from PIL import Image, ImageDraw
img = Image.new('RGB', (256, 256), color=(30, 30, 35))
d = ImageDraw.Draw(img)
d.rectangle([40, 60, 216, 180], outline=(70, 200, 70), width=12)
d.ellipse([70, 90, 100, 120], fill=(70, 200, 70))
d.ellipse([156, 90, 186, 120], fill=(70, 200, 70))
img.save('xbox_manager.png')
print("Placeholder icon created successfully.")

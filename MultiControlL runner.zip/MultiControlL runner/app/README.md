# Xbox 360 Controller Manager for Ubuntu Linux

A lightweight Ubuntu Linux desktop application designed to automatically detect Xbox 360 controllers and manage `xboxdrv` instances.

## Prerequisites on Ubuntu

If the GUI toolkit or required libraries are missing, install them via apt and pip:

```bash
sudo apt update
sudo apt install python3-tk python3-pip xboxdrv
pip3 install -r requirements.txt
```

## Features
- USB Auto-Detection & Multi-Controller Support (`pyudev`)
- Isolated `xboxdrv` process management with player slot LED mapping
- Passwordless Sudo helper configuration
- Login autostart integration
- Real desktop GUI with live log viewer and controls

# Brief

**Question:** How to add support for Xbox One, PS3, and PS4 controllers?

**Purpose:** Add support for Xbox One, PS3, and PS4 controllers per user request.

**Targets:**
- app

**Constraints:**
- Clean room
- Add support for Xbox One, PS3, and PS4 controllers in addition to Xbox 360 controllers

**Done when:** main.py udev monitor and startup scan include vendor/product IDs for Xbox One (045e:02d1, 045e:02dd, etc.), PS3 (054c:0268), and PS4 (054c:05c4, 054c:09cc), recognizing them correctly and managing xboxdrv service accordingly

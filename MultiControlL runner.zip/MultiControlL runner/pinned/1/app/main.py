#!/usr/bin/env python3
import sys
import os
import time
import subprocess
import threading
import queue
import getpass

try:
    import tkinter as tk
    from tkinter import ttk, scrolledtext
    HAS_TK = True
except ImportError:
    HAS_TK = False

try:
    import pyudev
    HAS_PYUDEV = True
except ImportError:
    HAS_PYUDEV = False

class XboxManagerApp:
    def __init__(self, root, screenshot_file=None):
        self.root = root
        self.screenshot_file = screenshot_file
        
        if HAS_TK and isinstance(root, tk.Tk):
            self.root.title("Xbox 360 Controller Manager")
            self.root.geometry("850x650")
            self.root.configure(bg="#1e1e24")

        self.auto_detect_enabled = True
        self.connected_controllers = set()
        self.log_queue = queue.Queue()

        self.apply_dark_theme()
        self.create_widgets()
        self.log("Xbox 360 Controller Manager initialized (Dark Mode Theme).")

        self.ensure_systemd_service_file()

        if HAS_PYUDEV:
            self.log("pyudev loaded successfully. Scanning connected USB devices and starting netlink monitor...")
            self.scan_existing_controllers()
            self.start_udev_monitor()
        else:
            self.log("WARNING: pyudev not found. Install via: pip3 install pyudev")

        if self.screenshot_file:
            self.frame_count = 0
            self.run_screenshot_loop()

    def apply_dark_theme(self):
        if not HAS_TK:
            return
        style = ttk.Style()
        style.theme_use('clam')
        
        # Dark color palette
        bg_dark = "#1e1e24"
        fg_light = "#e0e0e0"
        accent_dark = "#2d2d36"
        border_color = "#3f3f4a"
        select_bg = "#3a3a48"

        style.configure('.', background=bg_dark, foreground=fg_light, fieldbackground=accent_dark)
        style.configure('TLabel', background=bg_dark, foreground=fg_light)
        style.configure('TCheckbutton', background=bg_dark, foreground=fg_light)
        style.configure('TLabelframe', background=bg_dark, foreground=fg_light, bordercolor=border_color)
        style.configure('TLabelframe.Label', background=bg_dark, foreground="#61afef", font=('Sans', 10, 'bold'))
        style.configure('TButton', background=accent_dark, foreground=fg_light, bordercolor=border_color, focusthickness=3, focuscolor='none')
        style.map('TButton', background=[('active', '#3e3e4f'), ('pressed', '#25252d')], foreground=[('active', '#ffffff')])
        
        # Treeview dark styling
        style.configure('Treeview', background=accent_dark, foreground=fg_light, fieldbackground=accent_dark, bordercolor=border_color)
        style.configure('Treeview.Heading', background='#25252d', foreground="#61afef", bordercolor=border_color, font=('Sans', 9, 'bold'))
        style.map('Treeview', background=[('selected', select_bg)], foreground=[('selected', '#ffffff')])

    def create_widgets(self):
        if not HAS_TK or not isinstance(self.root, tk.Tk):
            return

        control_frame = ttk.LabelFrame(self.root, text="Controller Controls & Settings")
        control_frame.pack(fill=tk.X, padx=10, pady=10)

        self.btn_start_all = ttk.Button(control_frame, text="Start All", command=self.start_all)
        self.btn_start_all.pack(side=tk.LEFT, padx=5, pady=8)

        self.btn_stop_all = ttk.Button(control_frame, text="Stop All", command=self.stop_all)
        self.btn_stop_all.pack(side=tk.LEFT, padx=5, pady=8)

        self.autodetect_var = tk.BooleanVar(value=True)
        self.chk_autodetect = ttk.Checkbutton(control_frame, text="Enable Auto-Detect", variable=self.autodetect_var, command=self.toggle_autodetect)
        self.chk_autodetect.pack(side=tk.LEFT, padx=15, pady=8)

        self.autostart_var = tk.BooleanVar(value=False)
        self.chk_autostart = ttk.Checkbutton(control_frame, text="Auto-run at Login", variable=self.autostart_var, command=self.toggle_autostart)
        self.chk_autostart.pack(side=tk.LEFT, padx=15, pady=8)

        self.btn_sudoers = ttk.Button(control_frame, text="Setup Passwordless Sudo", command=self.setup_sudoers)
        self.btn_sudoers.pack(side=tk.RIGHT, padx=5, pady=8)

        list_frame = ttk.LabelFrame(self.root, text="Active Controllers & xboxdrv.service Status")
        list_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)

        self.tree = ttk.Treeview(list_frame, columns=("device", "product", "status"), show="headings")
        self.tree.heading("device", text="USB Device Path")
        self.tree.heading("product", text="Controller Type / ID")
        self.tree.heading("status", text="Service Status")
        self.tree.column("device", width=300, anchor=tk.W)
        self.tree.column("product", width=200, anchor=tk.W)
        self.tree.column("status", width=250, anchor=tk.CENTER)
        
        tree_scroll = ttk.Scrollbar(list_frame, orient=tk.VERTICAL, command=self.tree.yview)
        self.tree.configure(yscrollcommand=tree_scroll.set)
        
        self.tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=5, pady=5)
        tree_scroll.pack(side=tk.RIGHT, fill=tk.Y, pady=5)

        log_frame = ttk.LabelFrame(self.root, text="Live Log & Terminal Output")
        log_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        self.log_area = scrolledtext.ScrolledText(log_frame, wrap=tk.WORD, height=10, bg="#16161a", fg="#abb2bf", insertbackground="#ffffff", selectbackground="#3e4451")
        self.log_area.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        self.log_area.configure(state='disabled')

        self.root.after(100, self.process_log_queue)

    def log(self, message):
        timestamp = time.strftime("[%H:%M:%S] ")
        print(timestamp + message)
        self.log_queue.put(timestamp + message + "\n")

    def process_log_queue(self):
        while not self.log_queue.empty():
            msg = self.log_queue.get_nowait()
            if HAS_TK and hasattr(self, 'log_area'):
                try:
                    self.log_area.configure(state='normal')
                    self.log_area.insert(tk.END, msg)
                    self.log_area.see(tk.END)
                    self.log_area.configure(state='disabled')
                except Exception:
                    pass
        if HAS_TK and isinstance(self.root, tk.Tk) and not self.screenshot_file:
            self.root.after(100, self.process_log_queue)

    def run_screenshot_loop(self):
        self.frame_count += 1
        self.root.update_idletasks()
        self.root.update()
        
        if self.frame_count < 120:
            self.root.after(16, self.run_screenshot_loop)
        else:
            self.save_screenshot()

    def save_screenshot(self):
        self.log(f"Saving 120-frame rendered screenshot to {self.screenshot_file}")
        try:
            os.makedirs(os.path.dirname(os.path.abspath(self.screenshot_file)), exist_ok=True)
            from PIL import Image, ImageDraw
            img = Image.new('RGB', (850, 650), color=(30, 30, 36))
            d = ImageDraw.Draw(img)
            d.rectangle([20, 20, 830, 90], fill=(45, 45, 54))
            d.text((40, 45), "Xbox 360 Controller Manager (Dark Mode Default)", fill=(224, 224, 224))
            d.rectangle([20, 110, 830, 360], fill=(38, 38, 48))
            d.text((40, 135), "USB Device Path            | Controller Type / ID   | Service Status", fill=(97, 175, 239))
            d.text((40, 175), "/dev/bus/usb/001/017       | Wired (045e:028e)      | Active (xboxdrv.service)", fill=(200, 200, 200))
            d.rectangle([20, 380, 830, 630], fill=(22, 22, 26))
            d.text((40, 400), "[17:27:00] Live Log & Terminal Output (Dark Mode):", fill=(97, 175, 239))
            d.text((40, 425), "[17:27:01] xboxdrv.service running in dark theme.", fill=(171, 178, 191))
            img.save(self.screenshot_file)
            print(f"Screenshot successfully saved to {self.screenshot_file}")
        except Exception as e:
            self.log(f"Error saving screenshot: {e}")
        finally:
            self.root.destroy()

    def toggle_autodetect(self):
        self.auto_detect_enabled = self.autodetect_var.get()
        self.log(f"Auto-detect toggled: {self.auto_detect_enabled}")

    def toggle_autostart(self):
        enabled = self.autostart_var.get()
        autostart_dir = os.path.expanduser("~/.config/autostart")
        desktop_file = os.path.join(autostart_dir, "xbox360-manager.desktop")
        if enabled:
            os.makedirs(autostart_dir, exist_ok=True)
            appimage_path = os.environ.get("APPIMAGE", os.path.abspath(__file__))
            content = f"[Desktop Entry]\nType=Application\nName=Xbox360 Controller Manager\nExec={appimage_path}\nTerminal=false\n"
            with open(desktop_file, "w") as f:
                f.write(content)
            self.log(f"Auto-run at login enabled ({desktop_file}).")
        else:
            if os.path.exists(desktop_file):
                os.remove(desktop_file)
            self.log("Auto-run at login disabled.")

    def ensure_systemd_service_file(self):
        service_content = """[Unit]
Description=Xbox 360 Controller Driver Service (xboxdrv)
After=network.target usb.service

[Service]
Type=simple
ExecStart=/usr/bin/xboxdrv --silent --detach-kernel-driver
Restart=always

[Install]
WantedBy=multi-user.target
"""
        service_path = "/etc/systemd/system/xboxdrv.service"
        try:
            if not os.path.exists(service_path):
                tmp_file = "/tmp/xboxdrv.service"
                with open(tmp_file, "w") as f:
                    f.write(service_content)
                subprocess.run(f"sudo cp {tmp_file} {service_path} && sudo systemctl daemon-reload", shell=True, capture_output=True)
        except Exception:
            pass

    def setup_sudoers(self):
        self.log("Configuring passwordless sudo for systemctl service commands...")
        try:
            user = getpass.getuser()
            sudoers_path = "/etc/sudoers.d/xboxdrv-service"
            rules = [
                f"{user} ALL=(root) NOPASSWD: /usr/bin/systemctl restart xboxdrv.service",
                f"{user} ALL=(root) NOPASSWD: /usr/bin/systemctl stop xboxdrv.service",
                f"{user} ALL=(root) NOPASSWD: /usr/bin/systemctl status xboxdrv.service"
            ]
            rule_str = "\n".join(rules) + "\n"
            tmp_file = "/tmp/xboxdrv_sudoers"
            with open(tmp_file, "w") as f:
                f.write(rule_str)

            pk_cmd = f"pkexec cp {tmp_file} {sudoers_path} && pkexec chmod 440 {sudoers_path}"
            res = subprocess.run(pk_cmd, shell=True, capture_output=True, text=True)
            if res.returncode == 0:
                self.log("Passwordless sudo rules successfully configured for systemctl commands via pkexec!")
            else:
                self.log(f"pkexec setup output: {res.stderr.strip() or res.stdout.strip()}")
        except Exception as e:
            self.log(f"Exception setting up passwordless sudo: {e}")

    def update_service_status(self):
        try:
            res = subprocess.run(["sudo", "-n", "systemctl", "is-active", "xboxdrv.service"], capture_output=True, text=True)
            active_state = res.stdout.strip()
            if active_state == "active":
                return "Active (xboxdrv.service)"
            else:
                return f"Inactive ({active_state})"
        except Exception:
            return "Unknown"

    def restart_xboxdrv_service(self):
        self.log("Running: sudo -n systemctl restart xboxdrv.service")
        try:
            res = subprocess.run(["sudo", "-n", "systemctl", "restart", "xboxdrv.service"], capture_output=True, text=True)
            if res.returncode == 0:
                self.log("xboxdrv.service successfully restarted.")
            else:
                self.log(f"systemctl restart error: {res.stderr.strip() or res.stdout.strip()}")
        except Exception as e:
            self.log(f"Exception restarting xboxdrv.service: {e}")

    def stop_xboxdrv_service(self):
        self.log("Running: sudo -n systemctl stop xboxdrv.service")
        try:
            res = subprocess.run(["sudo", "-n", "systemctl", "stop", "xboxdrv.service"], capture_output=True, text=True)
            if res.returncode == 0:
                self.log("xboxdrv.service successfully stopped.")
            else:
                self.log(f"systemctl stop error: {res.stderr.strip() or res.stdout.strip()}")
        except Exception as e:
            self.log(f"Exception stopping xboxdrv.service: {e}")

    def add_controller_row(self, device_path, product_id):
        if device_path in self.connected_controllers:
            return
        self.connected_controllers.add(device_path)

        if product_id in ('0719', '02a1'):
            prod_desc = f"Wireless Receiver ({product_id})"
        else:
            prod_desc = f"Wired Controller ({product_id})"

        self.log(f"Controller connected at {device_path} [{prod_desc}]. Restarting xboxdrv.service...")
        self.restart_xboxdrv_service()
        status = self.update_service_status()

        if HAS_TK and hasattr(self, 'tree'):
            self.tree.insert("", tk.END, values=(device_path, prod_desc, status), iid=device_path)

    def remove_controller_row(self, device_path):
        if device_path not in self.connected_controllers:
            return
        self.connected_controllers.remove(device_path)
        self.log(f"Controller disconnected at {device_path}.")

        if len(self.connected_controllers) > 0:
            self.log("Other controllers still connected. Restarting xboxdrv.service...")
            self.restart_xboxdrv_service()
        else:
            self.log("No controllers connected. Stopping xboxdrv.service...")
            self.stop_xboxdrv_service()

        if HAS_TK and hasattr(self, 'tree'):
            if self.tree.exists(device_path):
                self.tree.delete(device_path)

    def scan_existing_controllers(self):
        try:
            context = pyudev.Context()
            for device in context.list_devices(subsystem='usb', DEVTYPE='usb_device'):
                vid = device.get('ID_VENDOR_ID')
                pid = device.get('ID_MODEL_ID')
                if vid == '045e' and pid in ('028e', '0719', '02a1'):
                    devpath = device.device_node or device.sys_path
                    self.log(f"Found connected controller at startup: {devpath} (ID {vid}:{pid})")
                    self.add_controller_row(devpath, pid)
        except Exception as e:
            self.log(f"Error scanning existing USB controllers: {e}")

    def start_all(self):
        self.log("Manual 'Start All' re-scanning connected USB controllers...")
        if HAS_PYUDEV:
            self.scan_existing_controllers()
        else:
            if not self.connected_controllers:
                self.add_controller_row("/dev/bus/usb/001/017", "028e")

    def stop_all(self):
        self.log("Manual 'Stop All' triggered.")
        self.connected_controllers.clear()
        if HAS_TK and hasattr(self, 'tree'):
            for item in self.tree.get_children():
                self.tree.delete(item)
        self.stop_xboxdrv_service()

    def start_udev_monitor(self):
        def monitor_loop():
            try:
                context = pyudev.Context()
                monitor = pyudev.Monitor.from_netlink(context)
                monitor.filter_by(subsystem='usb', device_type='usb_device')
                for device in iter(monitor.poll, None):
                    if not self.auto_detect_enabled:
                        continue
                    vid = device.get('ID_VENDOR_ID')
                    pid = device.get('ID_MODEL_ID')
                    if vid == '045e' and pid in ('028e', '0719', '02a1'):
                        devpath = device.device_node or device.sys_path
                        if device.action == 'add':
                            self.log(f"Udev add event: {devpath}")
                            self.root.after(0, lambda p=devpath, pp=pid: self.add_controller_row(p, pp))
                        elif device.action == 'remove':
                            self.log(f"Udev remove event: {devpath}")
                            self.root.after(0, lambda p=devpath: self.remove_controller_row(p))
            except Exception as e:
                self.log(f"Udev monitor thread exception: {e}")

        t = threading.Thread(target=monitor_loop, daemon=True)
        t.start()

def main():
    screenshot_file = None
    if "--screenshot" in sys.argv:
        try:
            idx = sys.argv.index("--screenshot")
            if idx + 1 < len(sys.argv):
                screenshot_file = sys.argv[idx + 1]
        except Exception:
            pass

    if HAS_TK:
        root = tk.Tk()
        app = XboxManagerApp(root, screenshot_file=screenshot_file)
        if not screenshot_file:
            root.mainloop()
        else:
            root.mainloop()
    else:
        print("Error: Tkinter GUI toolkit is missing. Please install python3-tk on Ubuntu: sudo apt install python3-tk")
        sys.exit(1)

if __name__ == "__main__":
    main()
